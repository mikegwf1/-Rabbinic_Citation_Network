package globals;

public class Parameters
{
	//Talmud
	
	//public String rootInput = "C:/downloads/sefaria/Sefaria-Export-master/Sefaria-Export-master/json/Talmud/Bavli/";
	
	//public String outputMasterFile = "c:/corpora/Talmud/sefaria_extract/bavli.csv";
	
	//public String outputTestFile = "c:/corpora/Talmud/sefaria_test_simple/test.dat";
	
	public String outputTestFileDoubled = "c:/corpora/Tanach/sefaria_test_doubled/deuteronomy.dat";

	public String outputTestFileTripled = "c:/corpora/Tanach/sefaria_test_tripled/deuteronomy.dat";

	//Tanach
	
	public String rootInput = "C:/downloads/sefaria/Sefaria-Export-master/json/Tanach";
	
	//public String outputMasterFile = "c:/corpora/Tanach/sefaria_extract/tanach.csv";
	public String outputMasterFile = "c:/corpora/Tanach/benSiraFiltered.txt";
	
	public String outputTestFile = "c:/corpora/Tanach/sefaria_test_simple/benSira.dat";
	
	//public String outputTestFileN = "c:/corpora/Tanach/sefaria_test_tripled/deuteronomy.dat";
	
	//public String outputTestFileN = "c:/corpora/Tanach/sefaria_test_tripled/proverbs.dat";
	public String outputTestFileN = "c:/corpora/Tanach/sefaria_test_tripled/benSira.dat";

	//public String selection = "genesis-exodus-leviticus-numbers";
	//public String selection = "ezra-nehemiah";
	//public String selection = "proverbs";
	public String selection = "";
	
	public int nFactor = 3;
	public boolean removePrefixes = false;
	
	public String inputSefariaDavidsonTalmudPath = "C:/corpora/sefaria/DavidsonTalmud/";
	public String inputSefariaDavidsonTalmud = inputSefariaDavidsonTalmudPath + "talmud.json";
	public String outputSefariaDavidsonTalmud = "C:/corpora/sefaria/DavidsonTalmud/Tractates/";
}
