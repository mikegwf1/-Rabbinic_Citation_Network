package bll;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.google.gson.Gson;

import globals.*;
import utils.*;

public class ProcessDavidsonSefaria
{
	Parameters par;
	
	public ProcessDavidsonSefaria(Parameters p)
	{
		par = p;
	}
	
	public void processDavidsonSefariaTop()
	{
		try
		{
			processDavidsonSefaria();
		}
		catch (Exception e)
		{
			try
			{
				PrintWriter pw = new PrintWriter(new FileOutputStream(par.inputSefariaDavidsonTalmudPath + "Exception Dump.log"));     
				e.printStackTrace(pw);
				pw.close();
				System.out.println("Generated Exception");
			}
			catch (Exception e1)
			{
				e1.printStackTrace();
			}
			System.exit(1);
		}
	}
	
	public void processDavidsonSefaria() throws Exception
	{
		List<SefariaObjectTalmudDavidson> tractates = new ArrayList<SefariaObjectTalmudDavidson>();
		Gson gs = new Gson();

		File iF = new File(par.inputSefariaDavidsonTalmud);
    	BufferedReader iR = new BufferedReader(new InputStreamReader(new FileInputStream(iF),"UTF-8"));
    	//skip first open bracket.
    	iR.readLine();
    	
    	//convert each tractate to a SefariaObjectTalmudDavidson object
    	StringBuffer lb = null;
    	
    	while (true)
    	{
    		String line1 = iR.readLine();
    		//end when at end of file
    		if (line1.equals("}"))
    			break;
    		//not at end of file.  is this a special line, with a character in the third position?
    		if (!line1.substring(2, 3).equals(" "))
    		{
    			//special line.
    			//if end of a tractate process it.
    			if (line1.substring(2, 3).equals("]"))
    			{
    				lb.append("]}");
    				String ll = lb.toString();
    				SefariaObjectTalmudDavidson so = null;
    				try
    				{
    					so = gs.fromJson(ll, SefariaObjectTalmudDavidson.class);
    				}
    				catch (Exception e)
    				{
    					Path errPath = Paths.get(par.inputSefariaDavidsonTalmudPath + "badJson.txt");
    					BufferedWriter bwo = Files.newBufferedWriter(errPath,StandardCharsets.UTF_8);
    					bwo.write(ll);
    					bwo.close();
    					throw new Exception(e);
    				}
    				tractates.add(so);
    				System.out.println("Finished processing tractate: " + so.tractate);
    				continue;
    			}
    			//must be start of a tractate.
    	    	lb = new StringBuffer(100000000);
    	    	lb.append("{");
    	    	//get tractate name
    	    	int index = line1.substring(3).indexOf("\"");
    	    	String tractateName = line1.substring(3,index+3);
    	    	lb.append("tractate:" + "\"" + tractateName + "\""  + ",text:[");
    	    	continue;
    		}
    		lb.append(line1.trim());
    	}
    	iR.close();
    	
    	//tractate objects are not in the tractates list.  Output the list.
    	//now output the list
    	for (SefariaObjectTalmudDavidson so : tractates)
    	{
    		System.out.println("Outputting tracate: " + so.tractate);
    		//open an output file
    		Path oF = Paths.get(par.outputSefariaDavidsonTalmud + so.tractate + ".txt");
    		BufferedWriter bwo = Files.newBufferedWriter(oF,StandardCharsets.UTF_8);
    		
    		//loop through the amudim
    		AmudLabel al = new AmudLabel();
    		for (String[] amud : so.text)
    		{
    			if (amud.length == 0)
    			{
    				al.advanceAmud();
    				continue;
    			}
    			
    			//nonempty amud
				//output and advance the amud
				bwo.write(al.toString());
				bwo.newLine();
				al.advanceAmud();
				
				//loop through the lines in the amud
	   			for (String line : amud)
    			{
	   				//take out brackets
	   				line = line.replace("[", " ");
	   				line = line.replace("]", " ");
	   				line = line.replaceAll(",", " ");
	   				line = line.replaceAll("-", " ");
	   				line = line.replaceAll(":", " ");
	   				line = line.replaceAll(";", " ");
	   				//remove characters enclosed by parens
	   				line = line.replaceAll("\\(.*?\\)", "");
	   				//append period
    				line = line + ".";
    				bwo.write(line);
    				bwo.newLine();
    			}
	   			
    		}
    		
   			//finished all amudim in the tractate
   			bwo.close();

   			int x = 1;
    	}
	}

}
