package bll;

import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class ReadFileTest
{

	public void readFileTestTop()
	{
		try
		{
			readFileTest();
		}
		catch (Exception e)
		{
			try
			{
				PrintWriter pw = new PrintWriter(new FileOutputStream("c:/temp/Exception Dump.log"));     
				e.printStackTrace(pw);
				pw.close();
				System.out.println("Generated Exception");
			}
			catch (Exception e1)
			{
				e1.printStackTrace();
			}
			System.exit(1);
		}
	}
	
	public void readFileTest() throws Exception
	{
		String filePath = "C:\\corpora\\sefaria\\DavidsonTalmud\\Tractates\\Arakhin.txt";
		String content = new String(Files.readAllBytes(Paths.get(filePath)), StandardCharsets.UTF_8);
		
		String rabbi = content.substring(757, 767);
		
		System.out.println(rabbi);
	}
	
}
