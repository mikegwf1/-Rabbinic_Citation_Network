package utils;

public class SefariaObjectTalmudDavidson
{
	public String tractate;
	public String[][] text;
}
