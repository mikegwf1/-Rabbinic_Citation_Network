package utils;

public class AmudLabel 
{
	Integer daf;
	String amud;
	
	public AmudLabel()
	{
		daf = 1;
		amud = "A";
	}
	
    @Override
    public String toString() 
    { 
        return "[" + daf + amud + "]"; 
    } 
    
    public void advanceAmud()
    {
    	if (amud.equals("A"))
    		amud = "B";
    	else
    	{
    		daf++;
    		amud = "A";
    	}
    }

}
