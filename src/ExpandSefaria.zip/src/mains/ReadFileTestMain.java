package mains;

import bll.*;
import globals.*;

public class ReadFileTestMain
{

	static Parameters par = new Parameters();

	public static void main(String[] args)
	{
        System.out.println( "Starting ReadFileTestMain Process" );
        ReadFileTest bct = new ReadFileTest();
        bct.readFileTestTop();
        System.out.println( "Finished ReadFileTestMain Process" );
	}

}

