package mains;

import bll.*;
import globals.*;

public class ProcessDavidsonSefariaMain {

	static Parameters par = new Parameters();

	public static void main(String[] args)
	{
        System.out.println( "Starting ProcessDavidsonSefariaMain Process" );
        ProcessDavidsonSefaria bct = new ProcessDavidsonSefaria(par);
        bct.processDavidsonSefariaTop();
        System.out.println( "Finished ProcessDavidsonSefariaMain Process" );
	}

}
