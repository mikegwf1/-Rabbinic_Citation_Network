package db;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import globals.*;
import utilities.*;

public class DataBaseHelper
{
	Connection con;
	PreparedStatement selRabbisNotInSatlow;
	PreparedStatement insRabbiIntervals;
	PreparedStatement selAllRabbis;
	PreparedStatement insCitations;
	PreparedStatement selAllAmoraimByMasechet;
	PreparedStatement selAllTractateMap;
	PreparedStatement selAllQuotesSub1;

	public DataBaseHelper(Parameters par)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/" + par.dbName,"mike","asdfgh11");
			System.out.println("Database connected");
			con.setAutoCommit(false);
			
			String selRabbisNotInSatlowS = "select name from rabbis_not_in_satlow";
			selRabbisNotInSatlow = con.prepareStatement(selRabbisNotInSatlowS);
			
			String insRabbiIntervalsS = "insert into rabbi_intervals values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			insRabbiIntervals = con.prepareStatement(insRabbiIntervalsS);
			
			String selAllRabbisS = "select id, name, sortName, type, gen, genComputed, loc, city, link, occs, originalID from rabbis";
			selAllRabbis = con.prepareStatement(selAllRabbisS);
			
			String insCitationsS = "insert into citations values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			insCitations = con.prepareStatement(insCitationsS);
			
			String selAllAmoraimByMasechetS = "select masechet, afterLinkName, count, masechet_amoraic_ref, total_pct, masechet_pct from stat_computed_amoraim_ranked_by_masechet";
			selAllAmoraimByMasechet = con.prepareStatement(selAllAmoraimByMasechetS);
			
			String selAllTractateMapS = "select tractate_english, length from tractate_map";
			selAllTractateMap = con.prepareStatement(selAllTractateMapS);
			
			String selAllQuotesSub1S = "select ID, span_rabbis_text, first_rabbi_after_link, second_rabbi_after_link, masechet, start_span, end_span, amud, first_rabbi_after_link_id, second_rabbi_after_link_id from rabbi_quote_with_ids order by masechet, start_span";
			selAllQuotesSub1 = con.prepareStatement(selAllQuotesSub1S);
		}
		catch (Exception e)
		{
			System.out.println("Exception in DataBaseHelper constructor: " + e.getMessage());
			System.exit(1);
		}
	}
	
	public HashMap<String, Integer> getAllTractateMapLengths() throws Exception
	{
		HashMap<String, Integer> tls = new HashMap<String, Integer>();
		ResultSet rs = selAllTractateMap.executeQuery();
		while (rs.next())
		{
			String tractate = rs.getString(1);
			Integer length = rs.getInt(2);
			tls.put(tractate, length);
		}
		return tls;
	}
	
	public List<QuoteSub1> getAllQuotesSub1() throws Exception
	{
		List<QuoteSub1> qsl = new ArrayList<QuoteSub1>();
		ResultSet rs = selAllQuotesSub1.executeQuery();
		while (rs.next())
		{
			int ID = rs.getInt(1);
			String sp = rs.getString(2);
			String fi = rs.getString(3);
			String se = rs.getString(4);
			String ma = rs.getString(5);
			int st = rs.getInt(6);
			int en = rs.getInt(7);
			String am = rs.getString(8);
			int fri = rs.getInt(9);
			int sri = rs.getInt(10);
			QuoteSub1 qs = new QuoteSub1(ID, sp, fi, se, ma, st, en, am, fri, sri);
			qsl.add(qs);
		}
		return qsl;
	}
	
	public List<Rabbi> getAllRabbis() throws Exception
	{
		List<Rabbi> rabbis = new ArrayList<Rabbi>();
		ResultSet rs = selAllRabbis.executeQuery();
		while (rs.next())
		{
			Integer ID = rs.getInt(1);
			String name = rs.getString(2);
			String sortName = rs.getString(3);
			String type = rs.getString(4);
			String gen = rs.getString(5);
			Double genComputed = rs.getDouble(6);
			String loc = rs.getString(7);
			String city = rs.getString(8);
			Integer link = rs.getInt(9);
			Integer occs = rs.getInt(10);
			Integer originalID = rs.getInt(11);
			
			Rabbi rabbi = new Rabbi(ID, name, sortName, type, gen, genComputed, loc, city, link, occs, originalID);
			rabbis.add(rabbi);
		}
		return rabbis;
	}
	
	public List<StatComputedAmoraimRankedByMasechet> getAllStatComputedAmoraimRankedByMasechet() throws Exception
	{
		List<StatComputedAmoraimRankedByMasechet> ams = new ArrayList<StatComputedAmoraimRankedByMasechet>();
		ResultSet rs = selAllAmoraimByMasechet.executeQuery();
		while (rs.next())
		{
			String masechet = rs.getString(1);
			String afterLinkName = rs.getString(2);
			int count = rs.getInt(3);
			int masechet_amoraic_ref = rs.getInt(4);
			double global_pct = rs.getDouble(5);
			double masechet_pct = rs.getDouble(6);
			
			StatComputedAmoraimRankedByMasechet am = new StatComputedAmoraimRankedByMasechet(masechet, afterLinkName, count,
					masechet_amoraic_ref, global_pct, masechet_pct);
			ams.add(am);
		}
		return ams;
	}
	
	/*
	public List<String> getRabbisNotInSatlow() throws Exception
	{
		List<String> rabbis = new ArrayList<String>();
		ResultSet rs = selRabbisNotInSatlow.executeQuery();
		while (rs.next())
		{
			String name = rs.getString(1);
			rabbis.add(name);
		}
		return rabbis;
	}
	*/
	
	public void insertIntoRabbiIntervals(int ID, RabbisInterval ri, String tokenString) throws Exception
	{
		insRabbiIntervals.setInt(1, ID);
		insRabbiIntervals.setInt(2, ri.containsQuestioned);
		insRabbiIntervals.setInt(3, ri.containsTarget);
		insRabbiIntervals.setInt(4, ri.isRabbi1Questioned);
		insRabbiIntervals.setInt(5, ri.isRabbi2Questioned);
		insRabbiIntervals.setInt(6, ri.isRabbi1Target);
		insRabbiIntervals.setInt(7, ri.isRabbi2Target);
		insRabbiIntervals.setInt(8, ri.containsNameof);
		insRabbiIntervals.setInt(9, ri.containsQuoterInSpan);
		insRabbiIntervals.setInt(10, ri.containsQuoterBeforeSpan);
		insRabbiIntervals.setInt(11, ri.containsQuestionerInSpan);
		insRabbiIntervals.setInt(12, ri.containsQuestionerBeforeSpan);
		insRabbiIntervals.setInt(13, ri.containsSpatialInSpan);
		insRabbiIntervals.setInt(14, ri.containsSpatialBeforeSpan);
		insRabbiIntervals.setInt(15, ri.containsActionInSpan);
		insRabbiIntervals.setInt(16, ri.containsActionBeforeSpan);
		insRabbiIntervals.setString(17, ri.spanRabbisText);
		insRabbiIntervals.setString(18, ri.firstRabbi);
		insRabbiIntervals.setString(19, ri.firstRabbiAfterPrefix);
		insRabbiIntervals.setString(20, ri.firstRabbiAfterLink);
		insRabbiIntervals.setString(21, ri.secondRabbi);
		insRabbiIntervals.setString(22, ri.secondRabbiAfterPrefix);
		insRabbiIntervals.setString(23, ri.secondRabbiAfterLink);
		insRabbiIntervals.setString(24, ri.rabbisAfterLinkAlphaOrder);
		insRabbiIntervals.setString(25, ri.intervalText);
		insRabbiIntervals.setString(26, tokenString);
		insRabbiIntervals.setInt(27, ri.numbInterventingTokens);
		insRabbiIntervals.setString(28, ri.file);
		insRabbiIntervals.setInt(29, (int)ri.startSpan);
		insRabbiIntervals.setInt(30, (int)ri.endSpan);
		insRabbiIntervals.setString(31, ri.amud);
		insRabbiIntervals.execute();
	}
	
	public void insertIntoCitations(Citation cit) throws Exception
	{
		insCitations.setInt(1, cit.ID);
		insCitations.setString(2, cit.textRabbiName);
		insCitations.setString(3, cit.afterPrefixName);
		insCitations.setInt(4, cit.afterPrefixID);
		insCitations.setString(5, cit.afterLinkName);
		insCitations.setInt(6, cit.afterLinkID);
		insCitations.setString(7, cit.snippet);
		insCitations.setString(8, cit.afterLinkType);
		insCitations.setString(9, cit.afterLinkGen);
		insCitations.setDouble(10, cit.afterLinkGenComputed);
		insCitations.setString(11, cit.afterLinkLoc);
		insCitations.setString(12, cit.afterLinkCity);
		insCitations.setInt(13, cit.truncatedFromID);
		insCitations.setString(14, cit.masechet);
		insCitations.setInt(15, cit.startOffset);
		insCitations.setInt(16, cit.endOffset);	
		insCitations.setString(17, cit.amud);	
		insCitations.setString(18, "");	
		insCitations.setInt(19, 0);	
		insCitations.setInt(20, 0);	
		insCitations.execute();
	}
	
	public void truncateCitations() throws Exception
	{
		Statement stmt = con.createStatement();
		String sql = "truncate table citations";
		stmt.execute(sql);
	}
	
	public void truncateRabbiIntervals() throws Exception
	{
		Statement stmt = con.createStatement();
		String sql = "truncate table rabbi_intervals";
		stmt.execute(sql);
	}
	
	public void commitTransaction()
	{
		try
		{
			con.commit();
		}
		catch (Exception e)
		{
			System.out.println("Exception in commitTransaction: " + e.getMessage());
			System.exit(1);
		}
	}

}
