package utilities;

public class StringAndCountSortAscending implements Comparable<StringAndCountSortAscending>
{
	public String str;
	public Integer cnt;
	
	public StringAndCountSortAscending(String s, Integer c)
	{
		str = s;
		cnt = c;
	}
	
	public int compareTo(StringAndCountSortAscending sac)
	{
		if (cnt < sac.cnt)
			return -1;
		
		if (cnt > sac.cnt)
			return 1;
		
		return 0;	
	}

}
