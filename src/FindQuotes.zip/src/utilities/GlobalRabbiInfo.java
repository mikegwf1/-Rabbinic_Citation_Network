package utilities;

import java.util.List;

public class GlobalRabbiInfo
{
	public String name;
	public Integer count;
	public List<Citation> citations;
	
	public GlobalRabbiInfo(String n, Integer c, List<Citation> l)
	{
		name = n;
		count = c;
		citations = l;
	}
}
