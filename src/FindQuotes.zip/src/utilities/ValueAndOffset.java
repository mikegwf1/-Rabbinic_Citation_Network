package utilities;

public class ValueAndOffset implements Comparable<ValueAndOffset>
{
	public String value;
	public int offset;
	public int endset;
	
	public ValueAndOffset(String v, int o, int e)
	{
		value = v;
		offset = o;
		endset = e;
	}

	public int compareTo(ValueAndOffset vao)
	{
		if (offset < vao.offset)
			return -1;
		
		if (offset > vao.offset)
			return 1;
		
		return 0;	
	}

}
