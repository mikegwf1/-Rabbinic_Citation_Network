package utilities;

public class RabbisInterval
{
	public String spanRabbisText;
	public String firstRabbi;
	public String firstRabbiAfterPrefix;
	public String firstRabbiAfterLink;
	public String secondRabbi;
	public String secondRabbiAfterPrefix;
	public String secondRabbiAfterLink;
	public String rabbisAfterLinkAlphaOrder;
	public String intervalText;
	public String[] interveningTokens;
	public String file;
	public long startSpan;
	public long endSpan;
	public String amud;
	public int containsQuestioned;
	public int containsTarget;
	public int containsNameof;
	public int containsQuoterInSpan;
	public int containsQuoterBeforeSpan;
	public int containsQuestionerInSpan;
	public int containsQuestionerBeforeSpan;
	public int containsSpatialInSpan;
	public int containsSpatialBeforeSpan;
	public int containsActionInSpan;
	public int containsActionBeforeSpan;
	public int numbInterventingTokens;
	public int isRabbi1Target;
	public int isRabbi1Questioned;
	public int isRabbi2Target;
	public int isRabbi2Questioned;
	
	public RabbisInterval(String spt, 
			String fr, String frap, String fral, String sr, String srap, String sral, String ralao,
			String it, String[] its, String f, long sp, long ep, String am,
			int cq, int ct, int cno, int cqi, int cqb, int cqti, int cqtb, int csi, int csb, int cai, int cab, int nit,
			int ir1t, int ir1q, int ir2t, int ir2q)
	{
		spanRabbisText = spt;
		firstRabbi = fr;
		firstRabbiAfterPrefix = frap;
		firstRabbiAfterLink = fral;
		secondRabbi = sr;
		secondRabbiAfterPrefix = srap;
		secondRabbiAfterLink = sral;
		rabbisAfterLinkAlphaOrder = ralao;
		intervalText = it;
		interveningTokens = its;
		file = f;
		startSpan = sp;
		endSpan = ep;
		amud = am;
		containsQuestioned = cq;
		containsTarget = ct;
		containsNameof = cno;
		containsQuoterInSpan = cqi;
		containsQuoterBeforeSpan = cqb;
		containsQuestionerInSpan = cqti;
		containsQuestionerBeforeSpan = cqtb;
		containsSpatialInSpan = csi;
		containsSpatialBeforeSpan = csb;
		containsActionInSpan = cai;
		containsActionBeforeSpan = cab;
		numbInterventingTokens = nit;
		isRabbi1Target = ir1t;
		isRabbi1Questioned = ir1q;
		isRabbi2Target = ir2t;
		isRabbi2Questioned = ir2q;
	}

}
