package utilities;

public class NumberPair
{
	public Integer number1;
	public Integer number2;
	
	public NumberPair(Integer n1, Integer n2)
	{
		number1 = n1;
		number2 = n2;
	}
	
	public String toString()
	{
		return number1 + "," + number2;
	}
}
