package utilities;

public class QuoteSub1
{
	public int ID;
	public String span_rabbis_text;
	public String first_rabbi_after_link;
	public String second_rabbi_after_link;
	public String masechet;
	public int start_span;
	public int end_span;
	public String amud;
	public int first_rabbi_after_link_id;
	public int second_rabbi_after_link_id;
	
	public QuoteSub1(int I, String sp, String fi, String se, String ma, int st, int en, String am, int fri, int sri)
	{
		ID = I;
		span_rabbis_text = sp;
		first_rabbi_after_link = fi;
		second_rabbi_after_link = se;
		masechet = ma;
		start_span = st;
		end_span = en;
		amud= am;
		first_rabbi_after_link_id = fri;
		second_rabbi_after_link_id = sri;
	}
}
