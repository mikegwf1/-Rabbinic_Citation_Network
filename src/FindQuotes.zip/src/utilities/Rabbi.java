package utilities;

public class Rabbi implements Comparable<Rabbi>
{
	public Integer ID;
	public String name;
	public String sortName;
	public String type;
	public String gen;
	public Double genComputed;
	public String loc;
	public String city;
	public Integer link;
	public Integer occs;
	public Integer originalID; //if truncated name, ID derived from
	public boolean overrideEntry; //true if this entry trumps duplicates as it is an override on the Duplicates Excluded spreadsheet.
	
	public Rabbi (Integer I, String n, String sn, String t, String g, String lo, String c, Integer li, Integer o, Integer oID,
			boolean oe)
	{
		ID = I;
		name = n;
		sortName = sn;
		type = t;
		gen = g;
		genComputed = getGenComputer(gen);
		loc = lo;
		city = c;
		link = li;
		occs = o;
		originalID = oID;
		overrideEntry = oe;
	}
	
	public Rabbi (Integer I, String n, String sn, String t, String g, Double gc, String lo, String c, Integer li, Integer o, Integer oID)
	{
		ID = I;
		name = n;
		sortName = sn;
		type = t;
		gen = g;
		genComputed = gc;
		loc = lo;
		city = c;
		link = li;
		occs = o;
		originalID = oID;
	}
	
	private double getGenComputer(String gen)
	{
		//System.out.println(gen);
		if (gen.isEmpty())
			return -1;
		if (gen.equals("1א"))
			return 1.3;
		if (gen.equals("1ב"))
			return 1.6;
		if (gen.contains("/"))
		{
			String[] segs = gen.split("/");
			return avg(segs);
		}
		if (gen.contains("-"))
		{
			String[] segs = gen.split("-");
			return avg(segs);
		}
		return new Double(gen);
	}
	
	private double avg(String[] segs)
	{
		double d1 = new Double(segs[0]);
		double d2 = new Double(segs[1]);
		return (d1+d2)/2;
	}
	
	public int compareTo(Rabbi r)
	{
		return sortName.compareTo(r.sortName);
	}
}
