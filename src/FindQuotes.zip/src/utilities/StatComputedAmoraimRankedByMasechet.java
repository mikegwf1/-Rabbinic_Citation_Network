package utilities;

public class StatComputedAmoraimRankedByMasechet
{
	public String masechet;
	public String afterLinkName;
	public int count;
	public int masechet_amoraic_ref;
	public double global_pct;
	public double masechet_pct;
	
	public StatComputedAmoraimRankedByMasechet(String m, String a, int c, int mar, double g, double mp)
	{
		masechet = m;
		afterLinkName = a;
		count = c;
		masechet_amoraic_ref = mar;
		global_pct = g;
		masechet_pct = mp;
	}
}
