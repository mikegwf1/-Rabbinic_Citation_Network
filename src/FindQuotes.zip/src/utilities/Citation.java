package utilities;

public class Citation
{
	public Integer ID;
	public String textRabbiName;;
	public String afterPrefixName;
	public String afterLinkName;
	public String masechet;
	public Integer startOffset;
	public Integer endOffset;
	public String amud;
	public String snippet;
	public Integer afterPrefixID;
	public Integer afterLinkID;
	public String afterLinkType;
	public String afterLinkGen;
	public Double afterLinkGenComputed;
	public String afterLinkLoc;
	public String afterLinkCity;
	public Integer truncatedFromID; 
	
	public Citation(Integer i, String trn, String apn, String aln, String m, Integer st, Integer end, String am, String s,
			Integer api, Integer ali, String alt, String alg, Double algc, String all, String alc, Integer tfi)
	{
		ID = i;
		textRabbiName = trn;
		afterPrefixName = apn;
		afterLinkName = aln;
		masechet = m;
		startOffset = st;
		endOffset = end;
		amud = am;
		snippet = s;
		afterPrefixID = api;
		afterLinkID = ali;
		afterLinkType = alt;
		afterLinkGen = alg;
		afterLinkGenComputed = algc;
		afterLinkLoc = all;
		afterLinkCity = alc;
		truncatedFromID = tfi;
		
	}
}
