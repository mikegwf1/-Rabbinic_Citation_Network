package utilities;

public class StringPair
{
	public String string1;
	public String string2;
	
	public StringPair(String s1, String s2)
	{
		string1 = s1;
		string2 = s2;
	}
}
