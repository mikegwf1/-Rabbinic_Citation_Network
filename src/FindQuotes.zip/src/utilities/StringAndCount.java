package utilities;

public class StringAndCount implements Comparable<StringAndCount>
{
	public String str;
	public Integer cnt;
	
	public StringAndCount(String s, Integer c)
	{
		str = s;
		cnt = c;
	}
	
	public int compareTo(StringAndCount sac)
	{
		if (cnt < sac.cnt)
			return 1;
		
		if (cnt > sac.cnt)
			return -1;
		
		return 0;	
	}

}
