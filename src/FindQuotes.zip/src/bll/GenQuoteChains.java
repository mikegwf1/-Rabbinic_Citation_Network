package bll;

import globals.*;
import utilities.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import db.*;

public class GenQuoteChains
{
	private Parameters par;
	DataBaseHelper dbh;

	public GenQuoteChains()
	{
		par = new Parameters();
		dbh = new DataBaseHelper(par);
	}
	
	public void genQuoteChainsTop() throws Exception
	{
		System.out.println("Started generating quote chains");
		genQuoteChains();
		System.out.println("Finished generating quote chains");
	}
	
	private void genQuoteChains() throws Exception
	{
		//get list of all quotes in masechet, start offset order
		List<QuoteSub1> ams = dbh.getAllQuotesSub1();
		//create list to hold chains
		List<List<Integer>> chainsList = new ArrayList<List<Integer>>();
		List<List<String>> namesList = new ArrayList<List<String>>();
		
		//loop through quotes, finding all whose end_span falls into the start_span:end_span of the next quote
		List<Integer> currentChain = new ArrayList<Integer>();
		List<String> currentNames = new ArrayList<String>();
		QuoteSub1 lastQuote = null;
		for (QuoteSub1 am : ams)
		{
			if (lastQuote != null)
			{
				if (lastQuote.masechet.equals(am.masechet) && lastQuote.end_span >= am.start_span)
				{
					if (currentChain.size() == 0)
					{
						currentChain.add(lastQuote.ID);
						currentNames.add(lastQuote.first_rabbi_after_link);
					}
					currentChain.add(am.ID);
					currentNames.add(am.first_rabbi_after_link);
				}
				else
				{
					if (currentChain.size() > 0)
					{
						chainsList.add(currentChain);
						currentChain = new ArrayList<Integer>();
						currentNames.add(lastQuote.second_rabbi_after_link); //for the last quote in the chain, we need to add the second rabbi
						namesList.add(currentNames);
						currentNames = new ArrayList<String>();
					}
				}
			}
			lastQuote = am;
		}
		
		//chains of IDs are put together.  Output.
		//first put quotes in hash map, keyed by ID
		HashMap<Integer, QuoteSub1> quotesByID = new HashMap<Integer, QuoteSub1>();
		for (QuoteSub1 am : ams)
		{
			quotesByID.put(am.ID, am);
		}
		
		//get stats
		HashMap<Integer, Integer> stats = new HashMap<Integer,Integer>();
		for (Integer i=1; i<10; i++)
			stats.put(i, 0);
			
		for (List<Integer> chain : chainsList)
		{
			Integer len = chain.size();
			int y=0;
			if (len==4)
				y=1;
			Integer count = stats.get(len);
			stats.put(len, count+1);
		}
		
		//loop through chains, outputting pertinent information
		File fwChains = new File("C:/Talmud_Analysis/sefaria/001/SNA Analytics/quote_chains.csv");
		BufferedWriter wChains = new BufferedWriter(new FileWriter(fwChains));
		wChains.write("Chain Length, Rabbi1, Rabbi2, Rabbi3, Rabbi4, Rabbi5, Rabbi6, ID1, ID2, ID3, ID4, ID5, Span1, Span2, Span3, Span4, Span5, Masechet, Start Amud, End Amud");
		wChains.newLine();
		
		//file for Zeira
		File fwZeira = new File("C:/Talmud_Analysis/sefaria/001/SNA Analytics/Zeira_quote_chains_links.csv");
		BufferedWriter wZeira = new BufferedWriter(new FileWriter(fwZeira));
		wZeira.write("ID");
		wZeira.newLine();

		
		for (List<Integer> chain : chainsList)
		{
			StringBuffer lineb = new StringBuffer();
			//put chain length on line
			Integer len = chain.size();
			lineb.append(len+1 + ",");
			
			QuoteSub1 quote = null;

			//put rabbi names on line
			
			//first check for special rabbis.
			boolean bZeira = false;
			for (int i=0; i<len; i++)
			{
				quote = quotesByID.get(chain.get(i));
				if (quote.first_rabbi_after_link_id == 1017 || quote.second_rabbi_after_link_id == 1017) //Zeira
					bZeira = true;
			}

			int maxLength = 6;
			int ctr = 0;
			for (int i=0; i<len; i++)
			{
				quote = quotesByID.get(chain.get(i));
				lineb.append(quote.first_rabbi_after_link + ",");
				ctr++;
			}
			
			quote = quotesByID.get(chain.get(ctr-1));
			lineb.append(quote.second_rabbi_after_link + ",");
			ctr++;

			for (int i=ctr; i<maxLength; i++)
				lineb.append(",");
			
			//put ID's on line
			maxLength = 5; //one less than max rabbis for the rest of the items
			ctr = 0;
			
			//write quote IDs
			for (int i=0; i<len; i++)
			{
				quote = quotesByID.get(chain.get(i));
				lineb.append(quote.ID + ",");
				if (bZeira)
				{
					String idS = new Integer(quote.ID).toString();
					wZeira.write(idS);
					wZeira.newLine();
				}
				ctr++;
			}
			
			//write empty spaces for remainder of chain
			for (int i=ctr; i<maxLength; i++)
				lineb.append(",");
			
			//put spans online
			maxLength = 5; //one less than max rabbis for the rest of the items
			ctr = 0;
			for (int i=0; i<len; i++)
			{
				quote = quotesByID.get(chain.get(i));
				lineb.append(quote.span_rabbis_text + ",");
				ctr++;
			}
			for (int i=ctr; i<maxLength; i++)
				lineb.append(",");
			
			//append masechet, start amud, end amud
			quote = quotesByID.get(chain.get(0));
			String beg_amud = quote.amud;
			lineb.append(quote.masechet + "," + beg_amud + ",");
			quote = quotesByID.get(chain.get(len-1));
			String end_amud = quote.amud;
			lineb.append(end_amud);
			int y=0;
			if (!beg_amud.equals(end_amud))
				y=1;
			String line = lineb.toString();
			wChains.write(line);
			wChains.newLine();

		}
		
		wChains.close();
		wZeira.close();
		
	}
}

