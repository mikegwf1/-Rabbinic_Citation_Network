package bll;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GenRandomDafimAndQuotes
{
	public void genRandomDafimAndQuotesTop()
	{
		try
		{
			System.out.println("Starting Random Dafim and Quote Generation");
			genRandomDafimAndQuotes();
			System.out.println("Finished Random Dafim and Quote Generation");
		}
		catch (Exception e)
		{
			System.out.println("Exception in genRandomDafimAndQuotes: " + e.getMessage());
			System.exit(1);;
		}
	}
	
	private void genRandomDafimAndQuotes() throws Exception
	{
		//read list of dafim into a list
		List<String> dafim = new ArrayList<String>();
		File frDafim = new File("C:/Talmud_Analysis/dafyomi/Calendar for 13th dafyomi cycle.csv");
		BufferedReader rDafim = new BufferedReader(new FileReader(frDafim));
		while (true)
		{
			String line = rDafim.readLine();
			if (line == null|| line.isEmpty())
				break;
			System.out.println(line);
			String[] segs = line.split(",");
			dafim.add(segs[3]);
		}
		rDafim.close();
		//all dafim read. shuffle them.
		Collections.shuffle(dafim);
		
		//write out number to use
		int nDafim = 337;
		File fwDafim = new File("C:/Talmud_Analysis/dafyomi/randomDafim.csv");
		BufferedWriter wDafim = new BufferedWriter(new FileWriter(fwDafim));
		int ctr = 0;
		for (String daf : dafim)
		{
			wDafim.write(daf);
			wDafim.newLine();
			ctr++;
			if (ctr == nDafim)
				break;
		}
		wDafim.close();

		//now do quotes
		//read list of quotes into a list
		List<String> quotes = new ArrayList<String>();
		File frQuotes = new File("C:/Talmud_Analysis/sefaria/001/SNA Analytics/rabbi_quote.csv");
		BufferedReader rQuotes = new BufferedReader(new InputStreamReader(new FileInputStream(frQuotes),"UTF-8"));
		boolean firstFlag = true;
		String headerLine = null;
		while (true)
		{
			String line = rQuotes.readLine();
			if (line == null|| line.isEmpty())
				break;
			System.out.println(line);
			if (firstFlag)
			{
				headerLine = line;
				firstFlag = false;
				continue;
			}
			quotes.add(line);
		}
		rQuotes.close();
		//all quotes read. shuffle them.
		Collections.shuffle(quotes);
		//prepend the header at the front of the list.
		quotes.add(0, headerLine);

		//write out number to use
		int nquotes = 359 + 1; //the +1 is for the header
		File fwQuotes = new File("C:/Talmud_Analysis/sefaria/001/SNA Analytics/randomQuotes.csv");
		BufferedWriter wQuotes = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fwQuotes, false),"UTF-8"));
		ctr = 0;
		for (String quote : quotes)
		{
			String[] segs = quote.split(";");
			StringBuffer quoteSubsetbuf = new StringBuffer(segs[0]);
			for (int i=16; i<31; i++)
				quoteSubsetbuf.append(";" + segs[i]);
			String quoteSubset = quoteSubsetbuf.toString();
			wQuotes.write(quoteSubset);
			wQuotes.newLine();
			ctr++;
			if (ctr == nquotes)
				break;
		}
		wQuotes.close();
	}


}
