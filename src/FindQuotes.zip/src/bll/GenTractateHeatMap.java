package bll;

import globals.*;
import utilities.*;
import db.*;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.tc33.jheatchart.HeatChart;

public class GenTractateHeatMap
{
	private Parameters par;
	DataBaseHelper dbh;
	NumberFormat miFormatter = new DecimalFormat("0.000");

	public GenTractateHeatMap()
	{
		par = new Parameters();
		dbh = new DataBaseHelper(par);
	}
	
	public void genTractateHeatMapTop() throws Exception
	{
		System.out.println("Started generating masechtot heat map");
		genTractateHeatMap();
		System.out.println("Finished generating masechtot heat map");
	}
	
	private void genTractateHeatMap() throws Exception
	{
		//get list of all masechet amoraim combos
		List<StatComputedAmoraimRankedByMasechet> ams = dbh.getAllStatComputedAmoraimRankedByMasechet();
		
		//two passes thru the list.
		//first pass. get number masechet and amoraim, and assign them indices via hashmaps
		Integer masechetIndex = 0;
		Integer amoraIndex = 0;
		HashMap<String, Integer> masechetMap = new HashMap<String, Integer>();
		HashMap<String, Integer> amoraMap = new HashMap<String, Integer>();
		
		for (StatComputedAmoraimRankedByMasechet am : ams)
		{
			String masechet = am.masechet;
			String amora = am.afterLinkName;
			if (!masechetMap.containsKey(masechet))
			{
				masechetMap.put(masechet, masechetIndex);
				masechetIndex++;
			}
			if (!amoraMap.containsKey(amora))
			{
				amoraMap.put(amora, amoraIndex);
				amoraIndex++;
			}
		}
		
		//create an array of the masechet names
		String[] masechtot = new String[masechetIndex];
		//populate it
		Iterator it = masechetMap.entrySet().iterator();
		while (it.hasNext())
		{
			Map.Entry<String, Integer> pair = (Map.Entry<String,Integer>)it.next();
			masechtot[pair.getValue()] = pair.getKey();
		}
		
		//create an array of the amora names
		String[] amoraim = new String[amoraIndex];
		//populate it
		Iterator ita = amoraMap.entrySet().iterator();
		while (ita.hasNext())
		{
			Map.Entry<String, Integer> pair = (Map.Entry<String,Integer>)ita.next();
			amoraim[pair.getValue()] = pair.getKey();
		}
		
		//create matrix for masechet, amora counts
		double[][] matrix = new double[masechetIndex][amoraIndex];
		
		//second pass. populate the matrix.
		for (StatComputedAmoraimRankedByMasechet am : ams)
		{
			String masechet = am.masechet;
			String amora = am.afterLinkName;
			int count = am.count;
			masechetIndex = masechetMap.get(masechet);
			amoraIndex = amoraMap.get(amora);
			matrix[masechetIndex][amoraIndex] = count;
		}
		
		//populate matrix of difference between masechet amora vectors
		double[][] diffs = computeCosineDifference(matrix);
		
		//output spreadsheets and heat map based on count
		outputSpreadsheetsAndHeatMap(amoraim, masechtot, matrix, diffs, false);
		
		//this next section is redundant as dividing by tractate length does not affect the angle of the vector
		/*
		//now recompute based on amoraic density.
		//read all masechet lengths.
		HashMap<String, Integer> masechetLengths = dbh.getAllTractateMapLengths();
		
		//adjust all count
		for (int i=0; i<masechtot.length; i++)
		{
			//get length of this masechet
			Integer masechetLength = masechetLengths.get(masechtot[i]);
			for (int j=0; j<amoraim.length; j++)
				matrix[i][j] = matrix[i][j] / masechetLength.doubleValue();
		}
		
		//recompute diffs
		diffs = computeCosineDifference(matrix);
		
		//output spreadsheets and heat map based on density
		outputSpreadsheetsAndHeatMap(amoraim, masechtot, matrix, diffs, true);
		*/

		
	}

	private double[][] computeCosineDifference(double[][] vectors)
	{
		int numbVectors = vectors.length;

		double[][] simTable = new double[numbVectors][numbVectors];
		for (int i=0; i<numbVectors; i++)
			for (int j=0; j<numbVectors; j++)
			{
				double sim = computeSim(vectors[i], vectors[j]);
				simTable[i][j] = sim;
			}
		return simTable;
	}

	private void outputSpreadsheetsAndHeatMap(String[] amoraim, String[] masechtot, double[][] matrix, 
			double[][] diffs, boolean densityFlag) throws Exception
	{
		String densityExt = "Count";
		if (densityFlag)
			densityExt = "Density";
		
		//output the masechet x amora matrix as a spreadsheet
		File oFb = new File(par.outputFolder + "Tractate Rabbi Reference " + densityExt + ".csv");
		BufferedWriter oRb = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(oFb),"UTF-8"));

		//output header
		String oLine = "";
		for (int i=0; i<amoraim.length; i++)
			oLine = oLine + "," + amoraim[i];
		oRb.write(oLine);
		oRb.newLine();

		//output masechet x amora matrix
		for (int i=0; i<masechtot.length; i++)
		{
			oLine = masechtot[i];
			for (int j=0; j<amoraim.length; j++)
				oLine = oLine + "," + miFormatter.format(matrix[i][j]);
			oRb.write(oLine.substring(0,oLine.length()));
			oRb.newLine();
		}
		oRb.close();
		
		//output the  difference matrix as a spreadsheet
		File oF = new File(par.outputFolder + "Tractate Similarity Based on Amoraic References " + densityExt + ".csv");
		BufferedWriter oR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(oF),"UTF-8"));

		//output header
		oLine = "";
		for (int i=0; i<masechtot.length; i++)
			oLine = oLine + "," + masechtot[i];
		oR.write(oLine);
		oR.newLine();

		//output masechet x masechet matrix
		for (int i=0; i<masechtot.length; i++)
		{
			oLine = masechtot[i];
			for (int j=0; j<masechtot.length; j++)
				oLine = oLine + "," + miFormatter.format(diffs[i][j]);
			oR.write(oLine.substring(0,oLine.length()));
			oR.newLine();
		}
		oR.close();


		//now generate a heat chart as a .png file
		  HeatChart hc = new HeatChart(diffs);
		  hc.setXValues(masechtot);
		  hc.setYValues(masechtot);
		  hc.setLowValueColour(Color.YELLOW);
		  hc.setHighValueColour(Color.RED);
		  hc.setColourScale(5);
		  String filePath = par.outputFolder + "Tractate Similarity Based on Amoraic References " + densityExt + ".png";
		  File hcf = new File(filePath);
		  hc.saveToFile(hcf);
	

	}
	
	private double computeSim(double[] vec1, double vec2[])
	{
		int len = vec1.length;

		//compute dot product first
		double dot = 0;
		for (int i=0; i<len; i++)
			dot = dot + vec1[i]*vec2[i];

		//compute norms of the vectors.
		double norm1 = getNorm(vec1);
		double norm2 = getNorm(vec2);

		//computer cosine similarity
		double sim = dot / (norm1*norm2);
		return sim;
	}

	private double getNorm(double[] vec)
	{
		double norm = 0;
		for (int i=0; i<vec.length; i++)
			norm = norm + vec[i]*vec[i];
		norm = Math.sqrt(norm);
		return norm;
	}
	  

}
