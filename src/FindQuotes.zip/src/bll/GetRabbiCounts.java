package bll;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.FileUtils;

import javax.xml.bind.DatatypeConverter;

import gate.Annotation;
import gate.AnnotationSet;
import gate.Corpus;
import gate.Document;
import gate.DocumentContent;
import gate.Factory;
import gate.FeatureMap;
import gate.Gate;
import gate.LanguageAnalyser;
import gate.Node;
import gate.creole.SerialAnalyserController;
import gate.creole.gazetteer.DefaultGazetteer;

import globals.*;
import utilities.*;
import db.*;

public class GetRabbiCounts
{
	Parameters par;
	SerialAnalyserController pipeline;
	DataBaseHelper dbh;

	HashMap rabbisInText = new HashMap<String,Integer>();
	HashMap rabbisAfterPrefixMap = new HashMap<String,Integer>();
	HashMap rabbisAfterLinkMap = new HashMap<String,Integer>();
	HashMap prefixMap = new HashMap<String,String>();
	HashMap linkMap = new HashMap<String,String>();
	HashMap intervalMap = new HashMap<String, Integer>();
	
	HashMap<String,GlobalRabbiInfo> rabbisInTextAll = new HashMap<String,GlobalRabbiInfo>();
	HashMap<String,GlobalRabbiInfo> rabbisAfterPrefixMapAll = new HashMap<String,GlobalRabbiInfo>();
	HashMap<String,GlobalRabbiInfo> rabbisAfterLinkMapAll = new HashMap<String,GlobalRabbiInfo>();
	File globalErrorFile;
	BufferedWriter globalErrorWriter;
	Integer snippetCounter = 0;
	List<Citation> globalCitations = new ArrayList<Citation>();
	HashMap<String,Rabbi> rabbisByName = new HashMap<String,Rabbi>();
	
	List<RabbisInterval> ris = new ArrayList<RabbisInterval>();
	
    public static String new_line_chars = "["
			 + "\\u000C"  // form feed, \f - normally a page break
			 + "\\u000A"  // line feed, \n
			 + "\\u000D"  // carriage return, \r
			 + "\\u000B"  // line tabulation, \v - concretely it's a new line
			 + "\\u0085"  // next line (NEL)
			 + "\\u2029"  // PARAGRAPH SEPARATOR, \p{Zp}
			 + "\\u2028"  // LINE SEPARATOR, \p{Zl}
			 + "]";


	public GetRabbiCounts() throws Exception
	{
		par = new Parameters();
		dbh = new DataBaseHelper(par);
		
		globalErrorFile = new File(par.outputFolder + "GlobalErrorFile.txt");
		globalErrorWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(globalErrorFile,false),"UTF-8"));

		Gate.init();
		System.out.println("...GATE initialised");
		// load ANNIE plugin - you must do this before you can create tokeniser
		// or JAPE transducer resources.
		Gate.getCreoleRegister().registerDirectories(
				new File(Gate.getPluginsHome(), "ANNIE").toURI().toURL());


		//Create pipeline
		pipeline =
				(SerialAnalyserController)Factory.createResource(
						"gate.creole.SerialAnalyserController");

		//Create Tokenizer
		LanguageAnalyser tokeniser = (LanguageAnalyser)Factory.createResource(
				"gate.creole.tokeniser.DefaultTokeniser");

		//Create Gazetteer
		FeatureMap params = Factory.newFeatureMap();
		params.put("listsURL", new File(par.listFolder + "lists.def").toURI().toURL());
		params.put("encoding", "UTF-8");
		DefaultGazetteer defaultGazetteer = (DefaultGazetteer) Factory
				.createResource("gate.creole.gazetteer.DefaultGazetteer",
						params);

		//Create Jape

		LanguageAnalyser jape = (LanguageAnalyser)Factory.createResource(
				"gate.creole.Transducer", gate.Utils.featureMap(
						"grammarURL", new     
						File(par.activeFolder + "jape/main.jape").toURI().toURL(),
						"encoding", "UTF-8")); // ensure this matches the file


		//add elements to pipeline
		pipeline.add(tokeniser);
		pipeline.add(defaultGazetteer);
		pipeline.add(jape);

		//read in hashmaps
		File pF = new File(par.listFolder + "prefixMap.txt");
		BufferedReader pR = new BufferedReader(new InputStreamReader(new FileInputStream(pF),"UTF-8"));
		while (true)
		{
			String iLine = pR.readLine();
			if (iLine == null || iLine.length() == 0)
				break;
			String[] segs = iLine.split("~");
			prefixMap.put(segs[0], segs[1]);
		}
		pR.close();

		File lF = new File(par.listFolder + "linkMap.txt");
		BufferedReader lR = new BufferedReader(new InputStreamReader(new FileInputStream(lF),"UTF-8"));
		lR.readLine(); //skip header line
		while (true)
		{
			String iLine = lR.readLine();
			if (iLine == null || iLine.length() == 0)
				break;
			//System.out.println(iLine);
			String[] segs = iLine.split("~");
			linkMap.put(segs[0], segs[1]);
		}
		lR.close();
		
		List<Rabbi> allRabbis = dbh.getAllRabbis();
		for (Rabbi r : allRabbis)
			rabbisByName.put(r.name, r);
	}

	public void getRabbiCounts() throws Exception
	{
		System.out.println("Getting Counts");

		//get list of files to process
		File iFD = new File(par.taCorporaFolder);
		File[] inputFiles = iFD.listFiles();

		//process all files
		for (File f : inputFiles)
		{
			if (f.getName().endsWith("txt"))
				processFile(f);
		}
		
		//output
		System.out.println("Outputting Results");
		outputRabbis(rabbisInText, "Rabbis as Found in Text");
		outputRabbis(rabbisAfterPrefixMap, "Rabbis After Removal of Prefixes");
		outputRabbis(rabbisAfterLinkMap, "Rabbis After Link Resolution");
		outputRabbiIntervals();
		outputRabbiIntervalCounts();
		
		outputCitations();

		System.out.println("Finished Getting Counts");

	}

	private void processFile(File f) throws Exception
	{
		//copy the file to the temp directory and perform substitutions
		File file1 = performSubstitutions(f);

		//create corpus
		Corpus corpus = Factory.newCorpus("JAPE corpus");

		//create document
		URL u = file1.toURI().toURL();
		FeatureMap params = Factory.newFeatureMap();
		params.put("sourceUrl", u);
		params.put("preserveOriginalContent", new Boolean(true));
		params.put("collectRepositioningInfo", new Boolean(true));
		params.put("encoding", "UTF-8");
		System.out.println("Creating doc for " + u);
		Document doc = (Document)
				Factory.createResource("gate.corpora.DocumentImpl", params);

		//add document to corpus
		corpus.add(doc);

		//add corpus to pipeline
		pipeline.setCorpus(corpus);

		//run the pipeline
		pipeline.execute();
		
		DocumentContent dc = doc.getContent();
		String documentText = dc.toString();

		//extract results
		System.out.println("Found annotations of the following types: " +
				doc.getAnnotations().getAllTypes());
		
		AnnotationSet resultAS0 = doc.getAnnotations();
		System.out.println("Number annotations: " + resultAS0.size());
		
		List<ValueAndOffset> rabbiNames = getAnnotOffsets(doc, resultAS0, "RabbiMatch");
		
		updateGlobalLists(rabbiNames, documentText, f, resultAS0);
		
		List<ValueAndOffset> rabbiSpans = getAnnotOffsets(doc, resultAS0, "RabbiSpanMatch");
		for (ValueAndOffset rabbiSpan : rabbiSpans)
		{
			long begSpan = rabbiSpan.offset;
			long endSpan = rabbiSpan.endset;
			DocumentContent dcr = dc.getContent(begSpan, endSpan);
			String spanRabbisText = dcr.toString();

			//if there are more than 2 rabbis in the span, skip it
			AnnotationSet rabbisInSpan = resultAS0.get("RabbiMatch", begSpan, endSpan);
			int numbRabbis = rabbisInSpan.size();
			if (numbRabbis > 2)
				continue;
			
			//only 2 rabbis
			
			//get offsets of rabbis within the span
			ValueAndOffset rabbi1 = getAnnotOffset(doc, resultAS0, "RabbiMatch1", begSpan, endSpan, -1);
			ValueAndOffset rabbi2 = getAnnotOffset(doc, resultAS0, "RabbiMatch2", begSpan, endSpan, rabbi1.offset);
			
			//AnnotationSet rb2a = resultAS0.get("RabbiMatch2", (long)rabbi2.offset, (long)rabbi2.endset);
			//Annotation rb2 = rb2a.get(0);
			//rb2a.remove(rb2);
			
			if (rabbi1.endset > rabbi2.offset)
			{
				String[] prePost = getPreAndPostSpanRabbisText(documentText, begSpan, endSpan);
				spanRabbisText = prePost[0] + "^" + spanRabbisText + "^" + prePost[1];
				System.out.println("Offset problems");
				System.exit(1);
			}
			
			DocumentContent iT = dc.getContent((long)rabbi1.endset, (long)rabbi2.offset);
			String intervalText = iT.toString();
			
			//clean up the text
			intervalText = removeCRLF(intervalText);
			String intervalTextWOPuncT = intervalText.replaceAll(",", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replaceAll("-", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replaceAll(":", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replaceAll(";", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			intervalTextWOPuncT = intervalTextWOPuncT.replace("  ", " ");
			
			String intervalTextWOPunc = intervalTextWOPuncT.trim();
			String interveningTokens[] = intervalTextWOPunc.split(" ");
			int numbInterventingTokens = 0;
			if (intervalTextWOPunc.length() > 0)
				numbInterventingTokens = interveningTokens.length;
			
			String[] prePost = getPreAndPostSpanRabbisText(documentText, begSpan, endSpan);
			spanRabbisText = prePost[0] + "^" + spanRabbisText + "^" + prePost[1];
			spanRabbisText = removeCRLF(spanRabbisText);
			spanRabbisText = spanRabbisText.replaceAll("-", "");
			String firstRabbi = rabbi1.value;
			String secondRabbi = rabbi2.value;
			
			//update maps for first rabbi
			//update rabbis count map
			updateMap(rabbisInText, firstRabbi);
			
			//update rabbis after prefix map
			String afterPrefix1 = null;
			if (!prefixMap.containsKey(firstRabbi))
			{
				System.out.println("Missing Entry in Prefix Map: " + firstRabbi);
				afterPrefix1 = firstRabbi;
			}
			else
				afterPrefix1 = (String)prefixMap.get(firstRabbi);
			updateMap(rabbisAfterPrefixMap, afterPrefix1);
			
			//update rabbis after link map
			String afterLink1 = afterPrefix1;
			if (linkMap.containsKey(afterPrefix1))
			{
				afterLink1 = (String)linkMap.get(afterPrefix1);
			}
			updateMap(rabbisAfterLinkMap, afterLink1);
			
			//update maps for second rabbi
			//update rabbis count map
			updateMap(rabbisInText, secondRabbi);
			
			//update rabbis after prefix map
			String afterPrefix2 = null;
			if (!prefixMap.containsKey(secondRabbi))
			{
				System.out.println("Missing Entry in Prefix Map: " + secondRabbi);
				afterPrefix2 = secondRabbi;
			}
			else
				afterPrefix2 = (String)prefixMap.get(secondRabbi);
			updateMap(rabbisAfterPrefixMap, afterPrefix2);
			
			//update rabbis after link map
			String afterLink2 = afterPrefix2;
			if (linkMap.containsKey(afterPrefix2))
			{
				afterLink2 = (String)linkMap.get(afterPrefix2);
			}
			updateMap(rabbisAfterLinkMap, afterLink2);

			//check for features
			int containsQuestioned = checkForFeature("RabbiQuestionedMatch", resultAS0, (long)begSpan, (long)endSpan);
			int containsTarget = checkForFeature("RabbiTargetMatch", resultAS0, (long)begSpan, (long)endSpan);
			int containsNameof = checkForFeature("NameofMatch", resultAS0, (long)begSpan, (long)endSpan);
			int containsQuoterInSpan = checkForFeature("QuoterMatch", resultAS0, (long)begSpan, (long)endSpan);
			long startPreSpan = (long)begSpan - prePost[0].length();
			int containsQuoterBeforeSpan = checkForFeature("QuoterMatch", resultAS0, (long)begSpan - prePost[0].length(), (long)begSpan);
			int quoterBlockersBeforeSpan = checkForFeature("QuoterBlockerMatch", resultAS0, (long)begSpan - prePost[0].length(), (long)begSpan);
			if (quoterBlockersBeforeSpan > 0)
			{
				if (containsQuoterBeforeSpan > 0)
					System.out.println("Quoter Blocked!");
				containsQuoterBeforeSpan = 0;
			}
			int containsQuestionerInSpan = checkForFeature("QuestionerMatch", resultAS0, (long)begSpan, (long)endSpan);
			int containsQuestionerBeforeSpan = checkForFeature("QuestionerMatch", resultAS0, (long)begSpan - prePost[0].length(), (long)begSpan);
			int containsSpatialInSpan = checkForFeature("SpatialMatch", resultAS0, (long)begSpan, (long)endSpan);
			int containsSpatialBeforeSpan = checkForFeature("SpatialMatch", resultAS0, (long)begSpan - prePost[0].length(), (long)begSpan);
			int containsActionInSpan = checkForFeature("ActionMatch", resultAS0, (long)begSpan, (long)endSpan);
			int containsActionBeforeSpan = checkForFeature("ActionMatch", resultAS0, (long)begSpan - prePost[0].length(), (long)begSpan);
			int isRabbi1Target = checkForFeature("RabbiTargetMatch", resultAS0, (long)rabbi1.offset, (long)rabbi1.endset);
			int isRabbi1Questioned = checkForFeature("RabbiQuestionedMatch", resultAS0, (long)rabbi1.offset, (long)rabbi1.endset);
			int isRabbi2Target = checkForFeature("RabbiTargetMatch", resultAS0, (long)rabbi2.offset, (long)rabbi2.endset);
			int isRabbi2Questioned = checkForFeature("RabbiQuestionedMatch", resultAS0, (long)rabbi2.offset, (long)rabbi2.endset);
			
			//construct an alpha order rep of the 2 rabbis so we can combine both directions.
			String afterLinkAlphaOrder = afterLink1 + "-" + afterLink2;
			if (afterLink2.compareTo(afterLink1) < 0)
				afterLinkAlphaOrder = afterLink2 + "-" + afterLink1;
			
			//get the amud
			String intervalAmud = getAmud(documentText, (int)begSpan); 

			RabbisInterval ri = new RabbisInterval(spanRabbisText, firstRabbi, afterPrefix1, afterLink1,
					secondRabbi,  afterPrefix2, afterLink2, afterLinkAlphaOrder, intervalText,
					interveningTokens, f.getName().substring(0,f.getName().length()-4), (long)begSpan, (long)endSpan-1, 
					intervalAmud, containsQuestioned,
					containsTarget, containsNameof, containsQuoterInSpan, containsQuoterBeforeSpan,
					containsQuestionerInSpan, containsQuestionerBeforeSpan,
					containsSpatialInSpan, containsSpatialBeforeSpan, containsActionInSpan, containsActionBeforeSpan,
					numbInterventingTokens,isRabbi1Target,isRabbi1Questioned,isRabbi2Target,isRabbi2Questioned);
			ris.add(ri);
			
			//update interval map counter
			String tokenString = "";
			for (String token : ri.interveningTokens)
				tokenString = tokenString + cleanToken(token) + " ";
			tokenString = tokenString.substring(0,tokenString.length()-1);

			updateMap(intervalMap, tokenString);
			
		}
		
		//finished 
		System.out.println("Number Rabbi Spans: " + rabbiSpans.size());
		//System.out.println("Finished");
	}
	
	private int checkForFeature(String featureName, AnnotationSet as, long startOff, long endOff)
	{
		AnnotationSet ras = as.get(featureName, startOff, endOff);
		return ras.size();
	}
	
	private String[] getPreAndPostSpanRabbisText(String docText, long startOffset, long endOffset)
	{
		StringBuffer preString = new StringBuffer();
		int nTokens = 0;
		for (long i = startOffset; i>0; i--)
		{
			int in = (int)i;
			String ch = docText.substring(in-1,in);
			/*
			if (ch.equals(".") || ch.equals("?") || ch.equals("!"))
				break;
			*/
			if (ch.equals(" "))
			{
				nTokens++;
				if (nTokens > par.numbPrePostTokens)
					break;
			}
			preString.append(ch);
		}
		preString.reverse();
		String preStringS = preString.toString();
		
		StringBuffer postString = new StringBuffer();
		nTokens = 0;
		for (long i = endOffset; i<=docText.length(); i++)
		{
			int in = (int)i;
			String ch = docText.substring(in,in+1);
			if (ch.equals(".") || ch.equals("?") || ch.equals("!"))
				break;
			if (ch.equals(" "))
			{
				nTokens++;
				if (nTokens > par.numbPrePostTokens)
					break;
			}
			postString.append(ch);
		}
		String postStringS = postString.toString();
		
		preStringS = preStringS.replaceAll("\\s"," ");
		postStringS = postStringS.replaceAll("\\s"," ");
		
		String[] prePost = {preStringS, postStringS};
		return prePost;
	}
	
	private String cleanToken(String token)
	{
		String tokenString = token.replaceAll("\\.", "");
		tokenString = tokenString.replaceAll("\\?", "");
		tokenString = tokenString.replaceAll("\\!", "");
		tokenString = tokenString.trim();
		return tokenString;
	}
	
	private String removeCRLF(String text)
	{
		//remove carriage return, line feed 
		String hexString = Hex.encodeHexString(text.getBytes());
		hexString = hexString.replaceAll("0d0a", "2020");
		byte[] bytes = DatatypeConverter.parseHexBinary(hexString);
		String oText = new String(bytes);
		return(oText);
	}
	
	private void outputRabbis(HashMap map, String fileName) throws Exception
	{
		int numbRabbis = 0;
		int numbOccs = 0;
		List<StringAndCount> rabbis = new ArrayList<StringAndCount>();
		Iterator iter = map.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<String,Integer> pair = (Map.Entry)iter.next();
			String name = pair.getKey();
			Integer count = pair.getValue();
			StringAndCount sac = new StringAndCount(name, count);
			rabbis.add(sac);
			numbRabbis++;
			numbOccs = numbOccs + count;
		}
		Collections.sort(rabbis);
		
		File f = new File(par.outputFolder + fileName + ".txt");
		BufferedWriter wR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f,false),"UTF-8"));
		wR.write("Number Rabbis: " + numbRabbis);
		wR.newLine();
		wR.write("Number Occurrences: " + numbOccs);
		wR.newLine();
		wR.newLine();
		for (StringAndCount sac : rabbis)
		{
			wR.write(sac.str + " - " + sac.cnt);
			wR.newLine();
		}
		wR.close();

	}
	
	private void outputRabbiIntervals() throws Exception
	{
		File f = new File(par.outputFolder + "Rabbi Intervals.csv");
		BufferedWriter wR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f,false),"UTF-8"));
		wR.write("Questioned Rabbi1~Questioned Rabbi2~Target Rabbi1~Target Rabbi2~"
				+ "Nameof~Quoter in Span~Quoter before Span~"
				+ "Questioner in Span~Questioner before Span~Spatial in Span~"
				+ "Spatial before Span~Action in Span~Action before Span~Spanning Text~"
				+ "First Rabbi~First Rabbi No Prefix~First Rabbi Linked~"
				+ "Second Rabbi~Second Rabbi No Prefix~Second Rabbi Linked~Rabbis Canonical~"
				+ "Interval Text~Interval Tokens~"
				+ "Number Interval Tokens~Masechet~Start Offset~End Offset~Amud");
		wR.newLine();
		
		dbh.truncateRabbiIntervals();
		int ID = 0;
		for (RabbisInterval ri : ris)
		{
			String tokenString = "";
			for (String token : ri.interveningTokens)
				tokenString = tokenString + cleanToken(token) + " ";
			tokenString = tokenString.substring(0,tokenString.length()-1);
			
			String line = ri.isRabbi1Questioned + "~" + ri.isRabbi2Questioned + "~" + 
							ri.isRabbi1Target + "~" + ri.isRabbi2Target + "~" + ri.containsNameof + "~" + 
							ri.containsQuoterInSpan + "~" + ri.containsQuoterBeforeSpan + "~" + 
							ri.containsQuestionerInSpan + "~" + ri.containsQuestionerBeforeSpan + "~" + 
							ri.containsSpatialInSpan + "~" + ri.containsSpatialBeforeSpan + "~" + 
							ri.containsActionInSpan + "~" + ri.containsActionBeforeSpan + "~" + 
							ri.spanRabbisText + "~" + 
							ri.firstRabbi + "~" + ri.firstRabbiAfterPrefix + "~" + ri.firstRabbiAfterLink + "~" + 
							ri.secondRabbi + "~" + ri.secondRabbiAfterPrefix + "~" + ri.secondRabbiAfterLink + "~" + 
							ri.rabbisAfterLinkAlphaOrder + "~" + ri.intervalText
							+ "~" + tokenString + "~" + ri.numbInterventingTokens + "~" + ri.file + "~"
							+ ri.startSpan + "~" + ri.endSpan + "~" + ri.amud;
		    wR.write(line);
		    wR.newLine();
		    
		    //write to db as well
		    ID++;
		    dbh.insertIntoRabbiIntervals(ID, ri, tokenString);
		}
		
		wR.close();
		dbh.commitTransaction();
	}
	
	private void outputRabbiIntervalCounts() throws Exception
	{
		File f = new File(par.outputFolder + "Interval Counts.csv");
		BufferedWriter wR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f,false),"UTF-8"));
		wR.write("Interval Tokens~Count");
		wR.newLine();
		
		List<StringAndCount> intervalTokens = new ArrayList<StringAndCount>();
		Iterator iter = intervalMap.entrySet().iterator();
		while (iter.hasNext())
		{
			Map.Entry<String,Integer> pair = (Map.Entry)iter.next();
			String interval = pair.getKey();
			Integer count = pair.getValue();
			StringAndCount sac = new StringAndCount(interval, count);
			intervalTokens.add(sac);
		}
		Collections.sort(intervalTokens);
		
		for (StringAndCount sac : intervalTokens)
		{
			wR.write(sac.str + "~" + sac.cnt);
			wR.newLine();
		}
		
		wR.close();
	}

	private void updateMap(HashMap<String, Integer> hm, String name)
	{
		if (hm.containsKey(name))
		{
			Integer cnt = hm.get(name);
			cnt++;
			hm.put(name, cnt);
		}
		else
			hm.put(name, 1);
	}

	private List<ValueAndOffset> getAnnotOffsets(Document doc, AnnotationSet as, String type) throws Exception
	{
		List<ValueAndOffset> vaos = new ArrayList<ValueAndOffset>();
		AnnotationSet dafs = as.get(type);
		for (Annotation daf : dafs)
		{
			Node start = daf.getStartNode();
			Node end = daf.getEndNode();
			long s = start.getOffset();
			long e = end.getOffset();
			DocumentContent dc = doc.getContent();
			DocumentContent dcr = dc.getContent(s, e);
			String text = dcr.toString();
			ValueAndOffset vao = new ValueAndOffset(text, (int)s, (int)e);
			vaos.add(vao);
		}
		Collections.sort(vaos);
		return vaos;
	}

	private ValueAndOffset getAnnotOffset(Document doc, AnnotationSet as, String type, long begOffset, long endOffset, int lastAnnot) throws Exception
	{
		AnnotationSet dafs = as.get(type, begOffset, endOffset);
		Annotation daf = dafs.inDocumentOrder().get(0);
		Node start = daf.getStartNode();
		Node end = daf.getEndNode();
		long s = start.getOffset();
		long e = end.getOffset();
		if (s == lastAnnot)
		{
			daf = dafs.inDocumentOrder().get(1);
			start = daf.getStartNode();
			end = daf.getEndNode();
			s = start.getOffset();
			e = end.getOffset();
			if (s == lastAnnot)
			{
				daf = dafs.inDocumentOrder().get(2);
				start = daf.getStartNode();
				end = daf.getEndNode();
				s = start.getOffset();
				e = end.getOffset();
				if (s == lastAnnot)
				{
					daf = dafs.inDocumentOrder().get(3);
					start = daf.getStartNode();
					end = daf.getEndNode();
					s = start.getOffset();
					e = end.getOffset();
					if (s == lastAnnot)
					{
						daf = dafs.inDocumentOrder().get(4);
						start = daf.getStartNode();
						end = daf.getEndNode();
						s = start.getOffset();
						e = end.getOffset();
						if (s == lastAnnot)
						{
							daf = dafs.inDocumentOrder().get(5);
							start = daf.getStartNode();
							end = daf.getEndNode();
							s = start.getOffset();
							e = end.getOffset();
						}
					}
				}
			}
		}
		DocumentContent dc = doc.getContent();
		DocumentContent dcr = dc.getContent(s, e);
		String text = dcr.toString();
		ValueAndOffset vao = new ValueAndOffset(text, (int)s, (int)e);
		return vao;
	}

	private File performSubstitutions(File inFile) throws Exception
	{
		//just copy the file if this is sefaria
		if (par.useSefaria)
		{
			String fileCopy = FileUtils.readFileToString(inFile);
			File outFile = new File(par.topFolder + "temp/" + inFile.getName());
			FileUtils.writeStringToFile(outFile, fileCopy, "UTF-8");
			return outFile;
		}
		//read the substitutions file and populate the substitution list.
		List<StringPair> subs = new ArrayList<StringPair>();
		File subsF = new File(par.activeFolder + "preprocess/expansions.txt");
		BufferedReader subsR = new BufferedReader(new FileReader(subsF));
		subsR.readLine(); //skip header
		while (true)
		{
			String line = subsR.readLine();
			if (line == null || line.isEmpty())
				break;
			String[] segs = line.split(",");
			subs.add(new StringPair(segs[0].trim(), segs[1].trim()));
		}
		subsR.close();
		//copy inFile to the temp folder after performing substitutions
		String fileContents = FileUtils.readFileToString(inFile);

		//take care of all cases of Masoret Hashas and brackets and parens
		//first delete everything within parens including the parens
		fileContents = fileContents.replaceAll("\\(.*?\\)", "");
		//change brackets surrounding the "daf" indicators so they wont be deleted.
		String rep = "~~$1~~";
		fileContents = fileContents.replaceAll("\\[דף(.*?)\\]",rep);
		//remove all square brackets, plus signs, and מסורת הש"ס
		fileContents = fileContents.replaceAll("\\[|\\]|\\+","");
		fileContents = fileContents.replaceAll("מסורת הש\"ס:", "");
		//restore brackets around the "daf" indicators
		rep = "\\[דף$1\\]";
		fileContents = fileContents.replaceAll("~~(.*?)~~",rep);

		//now perform substitutions in the file.
		for (StringPair sub : subs)
		{
			fileContents = fileContents.replaceAll(sub.string1, sub.string2);
		}

		fileContents = fileContents.replaceAll("ר'", "רבי"); //for some reason, apostrophe does not work when read from file, so we leave it here
		fileContents = fileContents.replaceAll("שנאמ'", "שנאמר"); //for some reason, apostrophe does not work when read from file, so we leave it here
		fileContents = fileContents.replaceAll("גורי'", "גוריה"); //for some reason, apostrophe does not work when read from file, so we leave it here
		/*
		  fileContents = fileContents.replaceAll("ריב\"ל", "רבי יהושע בן לוי");
		  fileContents = fileContents.replaceAll("ר\"ל", "ריש לקיש");
		  fileContents = fileContents.replaceAll("רשב\"ג", "רבן שמעון בן גמליאל");
		  fileContents = fileContents.replaceAll("דא\"ר", "דאמר רבי");
		  fileContents = fileContents.replaceAll("ודא\"ר", "ודאמר רבי");
		  fileContents = fileContents.replaceAll("כדא\"ר", "כדאמר רבי");
		  fileContents = fileContents.replaceAll("א\"ר", "אמר רבי");
		  fileContents = fileContents.replaceAll("וא\"ר", "ואמר רבי");
		  fileContents = fileContents.replaceAll("וא\"ר", "ואמר רבי");
		  fileContents = fileContents.replaceAll("וא\"ר", "ואמר רבי");
		  fileContents = fileContents.replaceAll("וא\"ר", "ואמר רבי");
		 */
		fileContents = fileContents.replaceAll(",", " ");
		fileContents = fileContents.replaceAll("-", " ");
		fileContents = fileContents.replaceAll(":", " ");
		fileContents = fileContents.replaceAll(";", " ");

		fileContents = fileContents.replaceAll("( )+", " ");
		File outFile = new File(par.topFolder + "temp/" + inFile.getName());
		FileUtils.writeStringToFile(outFile, fileContents, "UTF-8");
		return outFile;
	}
	
	private void updateGlobalLists(List<ValueAndOffset> rabbis, String documentText, File f, AnnotationSet resultAS0) throws Exception
	{
		String masechet = f.getName();
		masechet = masechet.substring(0,masechet.length()-4);

		for (ValueAndOffset rabbi : rabbis)
		{
			String textRabbiName = rabbi.value.trim().replaceAll(" +", " ");
			
			//get rabbi name after prefix map
			String afterPrefixName = null;
			if (!prefixMap.containsKey(textRabbiName))
			{
				globalErrorWriter.write("Missing Entry in Prefix Map: " + textRabbiName);
				afterPrefixName = textRabbiName;
			}
			else
				afterPrefixName = (String)prefixMap.get(textRabbiName);
			
			//get rabbi name after link resolution
			String afterLinkName = null;
			if (!linkMap.containsKey(afterPrefixName))
			{
				afterLinkName = afterPrefixName;
			}
			else
				afterLinkName = (String)linkMap.get(afterPrefixName);

			//get pre and post text
			String[] snips = getPreAndPostSpanRabbisText(documentText, rabbi.offset, rabbi.endset);
			
			//perform special screening on this rabbi name if necessary.
			if (afterPrefixName.equals("לוי"))
			{
				//see if there is a quoter near this name or another rabbi name.
				int nQuoters = checkForFeature("QuoterMatch", resultAS0, rabbi.offset-snips[0].length(), rabbi.endset+snips[1].length());
				int nRabbis = checkForFeature("RabbiMatch", resultAS0, rabbi.offset-snips[0].length(), rabbi.endset+snips[1].length());
				if (nQuoters == 0 && nRabbis == 1)  //if not, don't use in citation
					continue;
			}
			if (afterPrefixName.equals("חנניה"))
			{
				//skip if מישאל  is in the string
				if (snips[0].contains("מישאל") || snips[1].contains("מישאל"))
					continue;
			}
			
			/*
			if (afterPrefixName.equals("רב"))
			{
				//see if there is a quoter near this name or another rabbi name.
				int nQuoters = checkForFeature("QuoterMatch", resultAS0, rabbi.offset-snips[0].length(), rabbi.endset+snips[1].length());
				int nRabbis = checkForFeature("RabbiMatch", resultAS0, rabbi.offset-snips[0].length(), rabbi.endset+snips[1].length());
				if (nQuoters == 0 && nRabbis == 1)  //if not, don't use in citation
					continue;
			}
			*/
			
			//get amud
			String amud = getAmud(documentText, rabbi.offset);
			//create citation
			String snippet = snips[0] + "~" + textRabbiName + "~" + snips[1];
			snippetCounter++;
			Citation cit = null;
			cit = new Citation(snippetCounter, textRabbiName, afterPrefixName, afterLinkName, 
										masechet, rabbi.offset, rabbi.endset, amud, snippet,
										rabbisByName.get(afterPrefixName).ID, rabbisByName.get(afterLinkName).ID,
										rabbisByName.get(afterLinkName).type,rabbisByName.get(afterLinkName).gen,
										rabbisByName.get(afterLinkName).genComputed, rabbisByName.get(afterLinkName).loc,
										rabbisByName.get(afterLinkName).city,rabbisByName.get(afterPrefixName).originalID);
			//System.out.println(textRabbiName + ":" + afterPrefixName + ":" + afterLinkName);
			globalCitations.add(cit);
			/*
			//now update the 3 maps
			addToGlobalMap(rabbisInTextAll, textRabbiName, cit);
			addToGlobalMap(rabbisAfterPrefixMapAll, afterPrefixName, cit);
			addToGlobalMap(rabbisAfterLinkMapAll, afterLinkName, cit);
			*/
		}
	}
	
	private String getAmud(String text, int offset)
	{
		//find first "[" before this offset in the text
		int leftBrackIndex = text.lastIndexOf("[",offset);
		//find first following "]"
		int rightBrackIndex = text.indexOf("]",leftBrackIndex);
		String amud = text.substring(leftBrackIndex+1, rightBrackIndex);
		return amud;
	}
	
	private void outputCitations() throws Exception
	{
		dbh.truncateCitations();
		File ocF = new File(par.outputFolder + "AllNameReferences.txt");
		BufferedWriter ocW = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ocF,false),"UTF-8"));
		ocW.write("ID, Rabbi Name in Text, Rabbi Name w/o Prefix, Rabbi ID w/o Prefix, Rabbi Name after Link, Rabbi ID after Link, " + 
		"Snippet, Rabbi Type after Link, Rabbi Generation after Link, Rabbi Generation (Numeric) after Link, " +
		"Rabbi Location after Link, Rabbi City after Link, Rabbi Truncation Source ID, Masechet, Begin Offset, End Offset, Amud");
		ocW.newLine();
		
		for (Citation cit : globalCitations)
		{
			ocW.write(cit.ID + "," + cit.textRabbiName + "," + cit.afterPrefixName + "," + cit.afterPrefixID + "," + 
					  cit.afterLinkName + "," + cit.afterLinkID + "," + cit.snippet + "," + cit.afterLinkType + "," + 
					  cit.afterLinkGen + "," + cit.afterLinkGenComputed + "," + cit.afterLinkLoc + "," +
					  cit.afterLinkCity + "," + cit.truncatedFromID + "," +
					  cit.masechet + "," + cit.startOffset + "," + cit.endOffset + "," + cit.amud);
			ocW.newLine();
			dbh.insertIntoCitations(cit);
		}
		
		ocW.close();
		dbh.commitTransaction();
	}
	
	private void addToGlobalMap(HashMap<String,GlobalRabbiInfo> globalMap, String name, Citation cit)
	{
		//see if we have this rabbi yet in our hash.  Insert entry if not
		if (!globalMap.containsKey(name))
		{
			GlobalRabbiInfo newGri = new GlobalRabbiInfo(name, 0, new ArrayList<Citation>());
			globalMap.put(name, newGri);
		}
		
		//add this rabbi entry to its hash entry
		GlobalRabbiInfo gri = globalMap.get(name);
		gri.count++;
		List<Citation> citations = gri.citations;
		citations.add(cit);
		globalMap.put(name, gri);
	}


}
