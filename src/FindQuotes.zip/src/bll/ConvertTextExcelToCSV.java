package bll;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class ConvertTextExcelToCSV
{
	public void convertTextExcelToCSVTop()
	{
		try
		{
			convertTextExcelToCSV();
		}
		catch (Exception e)
		{
			System.out.println("Exception in convertTextExcelToCSV: " + e.getMessage());
			System.exit(1);;
		}
	}
	
	private void convertTextExcelToCSV() throws Exception
	{
		System.out.println("Started Reading Txt File");
		
		File f = new File("C:/Talmud_Analysis/satlow/Rabbis-Revised-20190327.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f),"UNICODE"));
		
		File fo = new File("C:/Talmud_Analysis/satlow/Rabbis-Revised-20190327.csv");
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fo,false),"UTF-8"));
		
		boolean firstLine = true;
		while (true)
		{
			String line = br.readLine();
			if (line == null || line.length() == 0 || line.replaceAll("\t", "").length() == 0)
				break;
			line = line.replaceAll("\t", ",");
			
			/*
			//put together rabbi name
			String rabbiName = "";
			int maxNameCol = 10;
			String segs[] = line.split(",");
			int numCols = segs.length;
			if (numCols < 11)
				maxNameCol = numCols - 1;
			for (int i=1; i<=maxNameCol; i++)
			{
				segs[i] = segs[i].trim();
				if (segs[i].isEmpty())
					break;
				if (segs[i].equals("ר'"))
					segs[i] = "רבי";
				if (i > 1)
					rabbiName = rabbiName + " ";
				rabbiName = rabbiName + segs[i];
			}
			
			//skip bogus rabbi names
			if (rabbiName.equals("בר"))
			{
				continue;
			}
			
			//append concatenated rabbi name
			if (firstLine)
			{
				firstLine = false;
				line = line + "," + "Complete Name";
			}
			else
				line = line + "," + rabbiName;
			
			//set linked field to 0 if it is blank
			segs = line.split(",");
			if (segs[11].isEmpty())
				segs[11] = "0";
			
			//put line back together
			line = "";
			for (int i=0; i<segs.length; i++)
				line = line + segs[i] + ",";
			line = line.substring(0,line.length()-1);
			*/

			bw.write(line);
			bw.newLine();
		}
		
		br.close();
		bw.close();
		System.out.println("Finished Reading Txt File");
		
		/*
		System.out.println("Started Reading non Satlow File");
		f = new File("C:/Talmud_Analysis/satlow/005/lists_satlow/rabbis_not_in_satlow.csv");
		br = new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"));
		br.readLine(); //skip header
		Integer ctr = 10000;
		
		while (true)
		{
			String line = br.readLine();
			if (line == null || line.length() == 0)
				break;
			line = line.trim();
			line = line.replaceAll("\"", "");
			String rabbiName = line;
			String[] segs = line.split(" ");
			String oLine = ctr.toString() + ",";
			ctr++;
			for (int i = 0; i <= segs.length-1; i++)
			{
				oLine = oLine + segs[i] + ",";
			}
			oLine = oLine.substring(0,oLine.length()-1);
			int totCommas = segs.length-1;
			for (int i = totCommas; i<14; i++)
			{
				if (i==10)
					oLine = oLine + "0,";
				else
					oLine = oLine + ",";
			}
			oLine = oLine + rabbiName;
			bw.write(oLine);
			System.out.println(oLine);
			bw.newLine();
		}
		
		bw.close();
		System.out.println("Finished Reading non Satlow File");
		*/
		
		System.out.println("Finished");
	}
}
