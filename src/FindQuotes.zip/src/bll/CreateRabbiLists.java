package bll;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import globals.*;
import utilities.*;
import db.*;

public class CreateRabbiLists
{
	Parameters par;
	
	List<String> rabbis_not_in_satlow;

	public CreateRabbiLists()
	{
		par = new Parameters();
	}
	
	public void createRabbiListsMatmidahTop() throws Exception
	{
		System.out.println("Started Creating Rabbi Lists Matmidah");
		
		File wF = new File(par.listFolder + "tanaiim_amoraiim_list.txt");
		BufferedWriter wR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(wF),"UTF-8"));

		File pF = new File(par.listFolder + "prefixMap.txt");
		BufferedWriter pR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pF),"UTF-8"));
		

		createRabbiListsMatmidah("", wR, pR, true);
		createRabbiListsMatmidah("ו", wR, pR, true);
		createRabbiListsMatmidah("ד", wR, pR, true);
		createRabbiListsMatmidah("ש", wR, pR, true);
		createRabbiListsMatmidah("ל", wR, pR, true);
		createRabbiListsMatmidah("מ", wR, pR, true);
		createRabbiListsMatmidah("כ", wR, pR, true);

		createRabbiListsMatmidah("וד", wR, pR, true);
		createRabbiListsMatmidah("וש", wR, pR, true);
		createRabbiListsMatmidah("ול", wR, pR, true);
		createRabbiListsMatmidah("ומ", wR, pR, true);
		createRabbiListsMatmidah("וכ", wR, pR, true);

		createRabbiListsMatmidah("כד", wR, pR, true);
		createRabbiListsMatmidah("שכ", wR, pR, true);

		createRabbiListsMatmidah("וכד", wR, pR, true);
		createRabbiListsMatmidah("מד", wR, pR, true);
		createRabbiListsMatmidah("אד", wR, pR, true);
		
		createRabbiListsMatmidah("ומד", wR, pR, true);
		createRabbiListsMatmidah("ואד", wR, pR, true);
		
		wR.close();
		pR.close();
		
		//create questioned and targets lists
		File qF = new File(par.listFolder + "tanaiim_amoraiim_list_questioned.txt");
		BufferedWriter qR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(qF),"UTF-8"));
		createRabbiListsMatmidah("מ", qR, null, false);
		qR.close();
		File tF = new File(par.listFolder + "tanaiim_amoraiim_list_targets.txt");
		BufferedWriter tR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tF),"UTF-8"));
		createRabbiListsMatmidah("ל", tR, null, false);
		tR.close();
		
		System.out.println("Finished Creating Rabbi Lists Matmidah");
	}

	private void createRabbiListsMatmidah(String prefix, BufferedWriter wR, BufferedWriter pR, boolean writeMap) throws Exception
	{
		//read and insert all rabbis to insert
		File rF = new File(par.listFolder + "rabbis_base.txt");
		BufferedReader rR = new BufferedReader(new InputStreamReader(new FileInputStream(rF),"UTF-8"));

		while (true)
		{
			String line = rR.readLine();
			if (line == null || line.length() == 0)
				break;
			
			String oRabbi = prefix + line;
			wR.write(oRabbi);
			wR.newLine();
			
			if (writeMap)
			{
				String oLine = oRabbi + "~" + line;
				pR.write(oLine);
				pR.newLine();
			}
		}
		
		rR.close();
	}


	public void createRabbiListsSatlowTop() throws Exception
	{
		System.out.println("Started Creating Rabbi Lists Satlow");
		
		createRabbisListsSatlow("", false);
		createRabbisListsSatlow("ו", true);
		createRabbisListsSatlow("ד", true);
		createRabbisListsSatlow("ש", true);
		createRabbisListsSatlow("ל", true);
		createRabbisListsSatlow("מ", true);
		
		createRabbisListsSatlow("", false);
		createRabbisListsSatlow("ו", true);
		createRabbisListsSatlow("ד", true);
		createRabbisListsSatlow("ש", true);
		createRabbisListsSatlow("ל", true);
		createRabbisListsSatlow("מ", true);
		createRabbisListsSatlow("כ", true);

		createRabbisListsSatlow("וד", true);
		createRabbisListsSatlow("וש", true);
		createRabbisListsSatlow("ול", true);
		createRabbisListsSatlow("ומ", true);
		createRabbisListsSatlow("וכ", true);

		createRabbisListsSatlow("כד", true);
		createRabbisListsSatlow("שכ", true);

		createRabbisListsSatlow("וכד", true);
		createRabbisListsSatlow("מד", true);
		createRabbisListsSatlow("אד", true);
		
		createRabbisListsSatlow("ומד", true);
		createRabbisListsSatlow("ואד", true);
		
		System.out.println("Finished Creating Rabbi Lists Satlow");
	}

	private void createRabbisListsSatlow(String prefix, boolean appendFlag) throws Exception
	{
		//open questioned and target output file if appropriate 
		File qtF = null;
		BufferedWriter qtR = null;
		if (prefix.equals("מ"))
		{
			qtF = new File(par.listFolder + "tanaiim_amoraiim_list_questioned.txt");
			qtR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(qtF),"UTF-8"));
		}
		if (prefix.equals("ל"))
		{
			qtF = new File(par.listFolder + "tanaiim_amoraiim_list_targets.txt");
			qtR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(qtF),"UTF-8"));
		}
		boolean qt = false;
		if (prefix.equals("מ") || prefix.equals("ל"))
			qt = true;

			
		//create HashMap to hold rabbi id's and names for link map
		HashMap idAndName = new HashMap();
		
		//create list to hold links during pass through file.  We will deal with them after picking up all names.
		List<NumberPair> links = new ArrayList<NumberPair>();
		
		//create HashMap to hold rabbi names and number of occurences
		HashMap<String, String> occs = new HashMap<String, String>();
		
		//create lists to hold rabbi names and links by primary and secondary
		List<StringAndCountSortAscending> linksByPrimary = new ArrayList<StringAndCountSortAscending>();
		List<StringAndCountSortAscending> linksBySecondary = new ArrayList<StringAndCountSortAscending>();
		//create list to hold plain name links.
		List<StringPair> linksPlain = new ArrayList<StringPair>();

		//read and insert all rabbis to insert
		File rF = new File(par.topFolder + par.inputFile);
		BufferedReader rR = new BufferedReader(new InputStreamReader(new FileInputStream(rF),"UTF-16"));

		File wF = new File(par.listFolder + "tanaiim_amoraiim_list.txt");
		BufferedWriter wR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(wF,appendFlag),"UTF-8"));
		
		File cF = new File(par.listFolder + "concatenated_names.txt");
		BufferedWriter cR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(cF,false),"UTF-8"));
		cR.write("ID, Link ID, Concatenated Name");
		cR.newLine();
		
		BufferedWriter wP = null;
		
		File pF = new File(par.listFolder + "prefixMap.txt");
		wP = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(pF,appendFlag),"UTF-8"));
			
		String line = "";
		//skip header lines
		line = rR.readLine();
		//line = rR.readLine();

		String[] segs = null;
		Integer ID = 0;
		Integer linkID = 0;
		int numCols = 0;
		while (true)
		{
			line = rR.readLine();
			if (line == null || line.length() == 0)
				break;
			segs = line.split("\t");
			ID = new Integer(segs[0]);
			numCols = segs.length;
			if (numCols == 1)
				break;
			
			//save link info, if any
			linkID = 0;
			if (numCols >= 12)
			{
				String linkField = segs[11];
				if (!linkField.isEmpty() && !linkField.equals("0"))
				{
					String linkIDS = linkField.replaceAll("\"", "");
					linkID = new Integer(linkIDS);
					NumberPair linkPair = new NumberPair(ID, linkID);
					links.add(linkPair);
				}
			}
			
			//put together rabbi name
			String rabbiName = "";
			int maxNameCol = 10;
			if (numCols < 11)
				maxNameCol = numCols - 1;
			for (int i=1; i<=maxNameCol; i++)
			{
				segs[i] = segs[i].trim();
				if (segs[i].isEmpty())
					break;
				if (segs[i].equals("ר'"))
					segs[i] = "רבי";
				if (i > 1)
					rabbiName = rabbiName + " ";
				rabbiName = rabbiName + segs[i];
			}
			
			//skip bogus rabbi names
			if (rabbiName.equals("בר"))
			{
				continue;
			}
			
			String origRabbiName = rabbiName;
			
			//save rabbi name and all ID occurrences
			String IDS = ID.toString();
			if (occs.containsKey(origRabbiName))
			{
				String IDs = occs.get(origRabbiName);
				IDs = IDs + "~" + IDS;
				occs.put(origRabbiName, IDs);
			}
			else
				occs.put(origRabbiName, IDS);	
			
			//add the prefix to the rabbi name
			rabbiName = prefix + rabbiName;
			//System.out.println("ID: " + ID + "  Link ID: " + linkID + "  Rabbi Name: " + rabbiName);
			
			//write out rabbi name with ID and link ID
			cR.write(ID + "," + linkID + "," + origRabbiName);
			cR.newLine();
			
			//insert into by ID hashmap after making sure id is not already there which would be an error
			if (idAndName.containsKey(ID))
			{
				System.out.println("***Error - duplicate ID: " + ID);
				System.exit(1);
			}
			idAndName.put(ID, origRabbiName);
			
			//write rabbi name to the rabbi name list
			wR.write(rabbiName);
			wR.newLine();
			//write to questioned/target file also if prefix is right
			if (qt)
			{
				qtR.write(rabbiName);
				qtR.newLine();
			}
			
			//write rabbi name and prefixed rabbi name to the prefix map
			String prefixMap = rabbiName + "~" + origRabbiName;
			wP.write(prefixMap);
			wP.newLine();

		}
		
		//finished reading all rabbi names.  Take care of links.
		if (!appendFlag)
		{
			File dF = new File(par.listFolder + "inconsistent_links.csv");
			BufferedWriter dR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dF),"UTF-8"));
			dR.write("Linkee,Linked to by,Links to");
			dR.newLine();

			for (NumberPair link : links)
			{
				//see if linker or linkee id is not valid
				if (!idAndName.containsKey(link.number1))
				{
					System.out.println("Missing linker in link pair: " + link);
					continue;
				}
				if (!idAndName.containsKey(link.number2))
				{
					System.out.println("Missing linkee in link pair: " + link);
					continue;
				}
				
				//see if there are any links where the linkee of this link is also a linker in another link.
				for (NumberPair clink : links)
				{
					if (clink.number1.equals(link.number2))
					{
						dR.write(link.number2 + "," + link.number1 + "," + clink.number2);
						dR.newLine();
					}
				}
				
				String linkee =  idAndName.get(link.number1) + "(" + link.number1.toString() + ")";
				String linker =  idAndName.get(link.number2) + "(" + link.number2.toString() + ")";
				String linkS = linkee + "," + linker;
				linksBySecondary.add(new StringAndCountSortAscending(linkS, link.number2));
				linksByPrimary.add(new StringAndCountSortAscending(linkS, link.number1));
				linksPlain.add(new StringPair((String)idAndName.get(link.number1), (String)idAndName.get(link.number2)));
			}
			dR.close();
		}
		
		
		wR.close();
		if (qt)
			qtR.close();
		rR.close();
		wP.close();
		cR.close();
		
		//if this is first time through
		if (!appendFlag)
		{
			File qF = new File(par.listFolder + "duprabbis.txt");
			BufferedWriter qR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(qF,false),"UTF-8"));
			qR.write("Count, Id's, Name");
			qR.newLine();
			
			//check for duplicate rabbi names
			List<StringAndCount> rabbis = new ArrayList<StringAndCount>();
			Iterator iter = occs.entrySet().iterator();
			while (iter.hasNext())
			{
				Map.Entry<String,String> pair = (Map.Entry)iter.next();
				String name = pair.getKey();
				String locs = pair.getValue();
				String locSegs[] = locs.split("~");
				Integer occCount = locSegs.length;
				int x = 1;
				if (occCount > 1)
					x = 2;
				name = name + "," + locs;
				StringAndCount sac = new StringAndCount(name, occCount);
				rabbis.add(sac);
			}
			
			//write out duplicate rabbi names
			Collections.sort(rabbis);
			for (StringAndCount sac : rabbis)
			{
				if (sac.cnt > 1)
				{
					String outp = sac.cnt + "," + sac.str;
					qR.write(outp);
					qR.newLine();
				}
			}
			qR.close();
			
			//write out unformatted file of links
			File plF = new File(par.listFolder + "linkMap.txt");
			BufferedWriter plR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(plF,false),"UTF-8"));
			plR.write("Secondary Name,Primary Name");
			plR.newLine();
			for (StringPair link : linksPlain)
			{
				plR.write(link.string1 + "~" + link.string2);
				plR.newLine();
			}
			plR.close();
			
			
			//write out links by linker
			Collections.sort(linksBySecondary);
			File kF = new File(par.listFolder + "linkMapBySecondary.txt");
			BufferedWriter kR = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(kF,false),"UTF-8"));
			kR.write("Secondary Name,Primary Name");
			kR.newLine();
			for (StringAndCountSortAscending sac : linksBySecondary)
			{
				kR.write(sac.str);
				kR.newLine();
			}
			kR.close();
			
			
			//write out links by linkee
			Collections.sort(linksByPrimary);
			File lF = new File(par.listFolder + "linkMapByPrimary.txt");
			BufferedWriter lP = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(lF,false),"UTF-8"));
			lP.write("Secondary Name,Primary Name");
			lP.newLine();
			for (StringAndCountSortAscending sac : linksByPrimary)
			{
				lP.write(sac.str);
				lP.newLine();
			}
			lP.close();

		}

	}
}
