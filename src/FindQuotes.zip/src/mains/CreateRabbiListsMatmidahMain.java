package mains;

import bll.*;

public class CreateRabbiListsMatmidahMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	CreateRabbiListsOld gs = new CreateRabbiListsOld();
	    	gs.createRabbiListsMatmidahTop();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}
