package mains;

import bll.*;

public class CreateRabbiListsSatlowMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	CreateRabbiLists gs = new CreateRabbiLists();
	    	gs.createRabbiListsSatlowTop();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}
