package mains;

import bll.*;

public class GenRandomDafimAndQuotesMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	GenRandomDafimAndQuotes grdq = new GenRandomDafimAndQuotes();
	    	grdq.genRandomDafimAndQuotesTop();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}
