package mains;

import bll.*;

public class GenTractateHeatMapMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	GenTractateHeatMap gthm = new GenTractateHeatMap();
	    	gthm.genTractateHeatMapTop();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}

