package mains;

import bll.*;

public class GetRabbiCountsMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	GetRabbiCounts grc = new GetRabbiCounts();
	    	grc.getRabbiCounts();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}
