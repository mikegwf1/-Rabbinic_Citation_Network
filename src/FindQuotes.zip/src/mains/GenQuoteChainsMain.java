package mains;

import bll.*;

public class GenQuoteChainsMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	GenQuoteChains gqc = new GenQuoteChains();
	    	gqc.genQuoteChainsTop();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}
