package mains;

import bll.*;

public class ConvertTextExcelToCSVMain
{
	  public static void main( String[] args )
	  {
	    try
	    {
	    	ConvertTextExcelToCSV grc = new ConvertTextExcelToCSV();
	    	grc.convertTextExcelToCSVTop();
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	  }
}
