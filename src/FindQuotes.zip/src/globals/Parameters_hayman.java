package globals;

public class Parameters_hayman
{
	/*
	public String topFolder = "c:/Talmud_Analysis/satlow/";
	public String subFolder = "006/";
	public String activeFolder = topFolder + subFolder;
	
	public String inputFile = "Rabbis-Revised-20190510.txt";
	
	public String version = "satlow";
	//public String version = "matmidah";
	*/
	
	public String topFolder = "c:/Talmud_Analysis/hayman/";
	public String subFolder = "001/";
	public String activeFolder = topFolder + subFolder;
	
	public String inputFile = "HaymanRabbis-20190619.txt";
	
	public String version = "hayman";

	
	public String listFolder = activeFolder + "lists_" + version + "/";
	public String outputFolder = activeFolder + "output_" + version + "/";

	public String taCorporaFolder = "C:/corpora/Talmud/Bar_Ilan/Text";
	//public String taCorporaFolder = "C:/Talmud_Analysis/satlow/input";
	
	public int maxInterveningTokens = 5;
	public int numbPrePostTokens = 5;

	//public String dbName = "memrot005";
	public String dbName = "hayman001";
	
	public boolean useSefaria = false; //set to true if using sefaria inputs

}
