package globals;

public class Parameters
{
	/*
	public String topFolder = "c:/Talmud_Analysis/satlow/";
	public String subFolder = "006/";
	public String activeFolder = topFolder + subFolder;
	
	public String inputFile = "Rabbis-Revised-20190510.txt";
	
	public String version = "satlow";
	//public String version = "matmidah";
	*/
	
	public String topFolder = "c:/Talmud_Analysis/sefaria/";
	public String subFolder = "001/";
	public String activeFolder = topFolder + subFolder;
	
	public String inputFile = "HaymanRabbis-20190619.txt";
	
	public String version = "sefaria";

	
	public String listFolder = activeFolder + "lists_" + version + "/";
	public String outputFolder = activeFolder + "output_" + version + "/";

	//public String taCorporaFolder = "C:/corpora/Talmud/Bar_Ilan/Text";
	//public String taCorporaFolder = "C:/Talmud_Analysis/satlow/input";
	public String taCorporaFolder = "C:/corpora/sefaria/DavidsonTalmud/Tractates";
	
	public int maxInterveningTokens = 5;
	public int numbPrePostTokens = 5;

	//public String dbName = "memrot005";
	//public String dbName = "hayman001";
	public String dbName = "sefaria001";
	
	public boolean useSefaria = true; //set to true if using sefaria inputs

}
